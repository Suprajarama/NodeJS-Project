const express = require('express');
const app = express();
const port = 3000;

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Define a route to render the index page
app.get('/', (req, res) => {
  // Get the current date and time
  const currentDate = new Date();

  // Render the index page with dynamic date and time
  res.render('index', { currentDate });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
