const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

let users = [];
let userAdded = false;

// Middleware to set currentDate for all routes
app.use((req, res, next) => {
    res.locals.currentDate = new Date();
    next();
});

app.get('/', (req, res) => {
    res.render('index', { users, userAdded });
    userAdded = false;
});

app.get('/users', (req, res) => {
    res.render('users', { users });
});

app.get('/contact', (req, res) => {
    res.render('contact');
});

app.get('/add-user', (req, res) => {
    res.render('add-user');
});

app.get('/delete-user', (req, res) => {
    res.render('delete');
});

app.post('/add-user', (req, res) => {
    const { name, gender } = req.body;
    const newUser = { name, gender };
    users.push(newUser);
    console.log(`User added: ${name} - ${gender}`);
    userAdded = true;
    res.redirect('/');
});

app.post('/delete-user', (req, res) => {
    const { name, gender } = req.body;

    // Find the index of the user to delete
    const indexToDelete = users.findIndex(user => user.name === name && user.gender === gender);

    if (indexToDelete !== -1) {
        // If found, remove the user
        users.splice(indexToDelete, 1);
        console.log(`User deleted: ${name} - ${gender}`);
    } else {
        console.log(`User not found: ${name} - ${gender}`);
    }

    res.redirect('/users');
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
