const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
const layouts = require('express-ejs-layouts');

const homeController = require('./controllers/homeController');
const errorController = require('./controllers/errorController');

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// Middleware to set currentDate for all routes
app.use((req, res, next) => {
    res.locals.currentDate = new Date();
    next();
});

app.get('/', (req, res) => {
    res.render('index');
});

app.get('/users', homeController.showUsers);
app.post('/users/submit', homeController.addUser);
app.post('/users/update', homeController.updateUser);
app.get('/contact', homeController.postSignUpForm);
app.get('/users/deleteUser', homeController.deleteUser);
app.post('/users/deleteUser', homeController.postDeleteuser);

app.use(errorController.pageNotFound);
app.use(errorController.respondInternalError);

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
