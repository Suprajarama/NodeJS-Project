'use strict';

const express = require('express');
const router = express.Router();
const User = require('../models/user');

// Connect to the database
const mongoose = require('mongoose');
const { name } = require('ejs');
mongoose.connect('mongodb://localhost:27017/my_database', { useNewUrlParser: true, useUnifiedTopology: true });

// This will route to the home page
router.get('/', (req, res, next) => {
    res.render('index', { title: 'Home' });
});

// Function to handle '/users' to show the list of users
router.showUsers = async (req, res) => {
    try {
        const users = await User.find();
        res.render('users', { users: users, title: "List of Users" });
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
};

// Function to handle '/users/submit' to submit the form data
router.addUser = async (req, res) => {
    const { name, gender } = req.body;
    try {
        await User.create({ name, gender });
        console.log(`User ${name} added successfully`);
        res.redirect('/users');
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
};

// Function to handle '/users/update' to update user information
router.updateUser = async (req, res) => {
    const { id, name, gender } = req.body;
    try {
        await User.findByIdAndUpdate(id, { name, gender });
        console.log(`User ${name} updated successfully`);
        res.redirect('/users');
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
};

// Function to handle '/contact' shows the post sign up form page
router.postSignUpForm = (req, res) => {
    console.log("in homeController postSignUpForm method");
    res.render("contact", { title: "Contact Us" });
};

router.deleteUser = (req, res) => {
    console.log("in homeController deleteUser");
    res.render("deleteUser", { title: "Delete User" });
};

router.postDeleteuser = async (req, res) => {
    const userIdToDelete = req.body.id; // Retrieve the user ID to delete
    try {
      // Find the user by ID and delete it from the database
      const deletedUser = await User.findByIdAndDelete(userIdToDelete);
        if (deletedUser) {
            console.log(`User ${deletedUser.name} is deleted`);
        } else {
            console.log(`User with ID ${userIdToDelete} not found`);
        }
        res.redirect('/users');
    } catch (err) {
      console.error(err);
      res.status(500).send('Internal Server Error');
    }
  };
  

module.exports = router;
